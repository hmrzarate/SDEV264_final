package com.androidatc.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class h : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_h)

        println("Welcome to the Rock, Paper, Scissors game!" +
                "To play:" +
                "Select rock, paper, or scissors by clicking on the corresponding word." +
                "The computer will then randomly select rock, paper, or scissors." +
                "If you win, your score count will go up." +
                "If you lose the computer's score count will go up." +
                "Test your rock, paper, scissor skills and see how many times you can beat " +
                "the computer!")
    }
}