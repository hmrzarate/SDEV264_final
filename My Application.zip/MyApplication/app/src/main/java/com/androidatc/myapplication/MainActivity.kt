package com.androidatc.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    restart_button.setOnClickListener{
        clear_score()

    }

    // when player clicks on rock icon
    rock.setOnClickListener {

    // choose a random number between 1 to 3
        val computer_move = (1..4).random()

        // 1 denotes rock

        // 2 denotes paper

        //3 denotes scissors

        if (computer_move ==1)  {
            println("Draw")
        }else if (computer_move ==2){
            println("Paper beats rock!")
            // increase the computer score
            val cscore: Int = computer_score.text.toString().toInt() + 1
            computer_score.text = cscore.toString()
        }else if (computer_move ==3)  {
            println("Rock beats scissors!")
            //increase the player score
            val pscore: Int = player_score.text.toString().toInt() + 1
            player_score.text = pscore.toString()
        }
    }

        // when player clicks on scissors icon
        scissors.setOnClickListener {

            // choose a random number between 1 to 3
            val computer_move = (1..4).random()

            // 1 denotes rock

            // 2 denotes paper

            //3 denotes scissors

            if (computer_move ==1)  {
                println("Rock beats scissors!")
                // increase the computer score
                val cscore: Int = computer_score.text.toString().toInt() + 1
                computer_score.text = cscore.toString()
            }else if (computer_move ==2){
                println("Scissors beat paper!")
                //increase the player score
                val pscore: Int = player_score.text.toString().toInt() + 1
                player_score.text = pscore.toString()
            }else if (computer_move ==3)  {
                println("Draw!")
            }

            // when player clicks on paper icon
            paper.setOnClickListener {

                // choose a random number between 1 to 3
                val computer_move = (1..4).random()

                // 1 denotes rock

                // 2 denotes paper

                //3 denotes scissors

                if (computer_move ==1)  {
                    println("Paper beats rock!")
                    //increase the player score
                    val pscore: Int = player_score.text.toString().toInt() + 1
                    player_score.text = pscore.toString()
                }else if (computer_move ==2){
                    println("Draw!")
                }else if (computer_move ==3)  {
                    println("Scissors beat paper!")
                    // increase the computer score
                    val cscore: Int = computer_score.text.toString().toInt() + 1
                    computer_score.text = cscore.toString()
                }







            }

            // when player clicks on help button
            h_button.setOnClickListener{
            var intent = Intent(this, h)
            }

            private fun clear_score() {
                // set the computer and player score to 0
                computer_score.text = "0"
                player_score.text = "0"
            }


}


